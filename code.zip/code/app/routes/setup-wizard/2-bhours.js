import Ember from 'ember';

export default Ember.Route.extend({
  actions :{
       clickevt: function(){
           alert('ss');
  }
}
});

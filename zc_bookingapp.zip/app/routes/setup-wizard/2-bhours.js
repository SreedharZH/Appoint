/* $Id$ */

import Ember from 'ember';

export default Ember.Route.extend({
  actions :{
       clickevt: function(){
           alert('ss'); // No I18N
  }
}
});

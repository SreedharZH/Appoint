/* $Id$ */

import Ember from 'ember';

export default Ember.Route.extend({
  redirect:function(){
     this.transitionTo('/my-desk.mydesk'); // No I18N
  }
});
